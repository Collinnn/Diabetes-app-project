 <!-- Responsible author: Christopher Zwinge
 * Contributors:
 -->
<template>
    <title>Page not found</title>
    <h1>404 page not found😡</h1>
</template>

<script>
export default {
    name: "pageNotFound"
}

</script>