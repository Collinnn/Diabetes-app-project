/*
 * Responsible author: Jacob Martens
 * Contributors:
 */
const requirement = {
    mounted(el) {
      el.style.fontFamily = 'verdana';
      el.style.fontSize = '12px';
    }
  }


  export default requirement